from django import forms
from .models import User


class LoginForm(forms.Form):
    username = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={
            "class": "form-control",
            "placeholder": "نام کاربری خود را وارد کنید",
        })
    )
    password = forms.CharField(
        max_length=100,
        widget=forms.PasswordInput(attrs={
            "class": "form-control",
            "placeholder": "رمز عبور خود را وارد کنید",
        })
    )


class SignUpForm(forms.ModelForm):
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            "class": "form-control",
            "placeholder": "رمز عبور خود را وارد کنید",
            "autocomplete": "new-password",
        })
    )

    class Meta:
        model = User
        fields = ["first_name", "last_name", "email", "username", "password"]
        widgets = {
            "first_name": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "نام خود را وارد کنید",
            }),
            "last_name": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "نام خانوادگی خود را وارد کنید",
            }),
            "email": forms.EmailInput(attrs={
                "class": "form-control",
                "placeholder": "ایمیل خود را وارد کنید",
            }),
            "username": forms.TextInput(attrs={
                "class": "form-control",
                "placeholder": "نام کاربری خود را وارد کنید",
            }),
        }

    # check if username already exists
    def clean_username(self):
        username = self.cleaned_data.get("username")
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("این نام کاربری قبلاً ثبت شده است.")
        return username

    # check if email already exists
    def clean_email(self):
        email = self.cleaned_data.get("email")
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("این ایمیل قبلاً ثبت شده است.")
        return email

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])
        if commit:
            user.save()
        return user
