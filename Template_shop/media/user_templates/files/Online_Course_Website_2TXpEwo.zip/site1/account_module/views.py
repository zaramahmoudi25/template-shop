from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from django.contrib.auth import login, authenticate, logout
from .forms import SignUpForm, LoginForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from account_module.models import UserProfile
from products.models import Course, Enrollment


def signup(request):
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "ثبت‌نام با موفقیت انجام شد! اکنون می‌توانید وارد شوید.")
            return redirect("index")
    else:
        form = SignUpForm()

    return render(request, "account_module/sign-up.html", {"form": form})


def login_view(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data["username"]
            password = form.cleaned_data["password"]
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect("index")
            else:
                form.add_error(None, "نام کاربری یا رمز عبور اشتباه است.")
    else:
        form = LoginForm()

    return render(request, "account_module/login.html", {"form": form})


def logout_view(request):
    logout(request)
    return redirect("index")


@login_required
def panel_user(request):
    profile, _ = UserProfile.objects.get_or_create(user=request.user)

    cart_items = profile.cart_items.all()
    cart_count = cart_items.count()

    total_courses = Course.objects.count()

    paid_courses = Enrollment.objects.filter(user=profile)
    paid_count = paid_courses.count()

    return render(request, 'panel-user.html', {
        'profile': profile,
        'user': request.user,
        'cart_items': cart_items,

        # dynamic stats
        'total_courses': total_courses,
        'cart_count': cart_count,
        'paid_count': paid_count,
        'paid_courses': paid_courses,
    })
