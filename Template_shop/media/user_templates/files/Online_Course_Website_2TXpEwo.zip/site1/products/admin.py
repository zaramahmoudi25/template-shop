from django.contrib import admin
from . import models
from .models import Course


admin.site.register(models.Role)
admin.site.register(models.Status)

admin.site.register(models.Field)
admin.site.register(models.Teacher)
admin.site.register(models.University)
admin.site.register(models.Education)
admin.site.register(models.TeacherInfo)

admin.site.register(models.Category)
admin.site.register(models.Color)
admin.site.register(models.Level)
admin.site.register(models.Syllabus)
admin.site.register(models.Tags)


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('title', 'teacher', 'level', 'hours', 'price')
    fields = ('title', 'teacher', 'level', 'syllabus', 'category', 'tags', 'hours', 'price', 'discount', 'description', 'image', 'views', 'intro_video')


admin.site.register(models.Enrollment)
admin.site.register(models.Blog)
admin.site.register(models.HeaderCourse)
admin.site.register(models.FutureCourse)
