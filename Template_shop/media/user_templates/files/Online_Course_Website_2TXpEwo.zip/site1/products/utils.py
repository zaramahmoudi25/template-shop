import re


def persian_slugify(value):
    value = str(value).strip()
    # Allowed: Persian letters, Arabic letters, numbers, and hyphens
    value = re.sub(r'[^ا-یءئأآؤ0-9\-]+', '-', value)
    value = re.sub(r'-+', '-', value).strip('-')
    return value
