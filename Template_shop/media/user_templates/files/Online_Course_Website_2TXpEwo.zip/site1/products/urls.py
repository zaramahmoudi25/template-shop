from django.urls import path
from . import views

urlpatterns = [
    path('article/', views.article),
    path('blog/', views.blog),
    path('contact/', views.contact),
    path('course/', views.course),
    path('error/', views.error),
    path('forget/', views.forget),
    path('', views.index),
    path('index/', views.index, name='index'),
    path('search/', views.search_view, name='search'),
    path('teach/', views.teach, name='teach'),
    path('cart/pay/', views.pay_cart, name='pay_cart'),

    path("course/<str:code_course>", views.coursedetail, name="coursedetail"),
    path('future-course/<str:code_futurecourse>', views.futurecoursedetail, name='futurecoursedetail'),
    path('article/<str:code_article>', views.articledetail, name='articledetail'),
    path('headercourse/<str:code_headercourse>', views.headercoursedetail, name='headercoursedetail'),
    path('category/<str:code_category>', views.categorydetail, name="categorydetail"),
    path('cart/add/<int:course_id>/', views.add_to_cart, name='add_to_cart'),
    path("autocomplete/", views.autocomplete_search, name="autocomplete"),

]
