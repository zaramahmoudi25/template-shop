from products.models import Category


def categories_processor(request):
    return {
        "Category": Category.objects.all()
    }
