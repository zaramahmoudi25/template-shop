from django.shortcuts import render
from . import models
from django.http import HttpResponse, JsonResponse
# from django.utils import timezone
from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Course, CartItem, Enrollment
from account_module.models import UserProfile
from django.contrib import messages


@login_required
def pay_cart(request):
    profile = UserProfile.objects.get(user=request.user)
    cart_items = profile.cart_items.all()

    if not cart_items:
        messages.info(request, "سبد خرید شما خالی است.")
        return redirect("panel_user")

    for item in cart_items:
        Enrollment.objects.create(
            user=profile,
            course=item.course,
            status=None
        )
        item.delete()

    messages.success(request, "پرداخت با موفقیت انجام شد!")
    return redirect("panel_user")


@login_required
def add_to_cart(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    profile = UserProfile.objects.get(user=request.user)

    item, created = CartItem.objects.get_or_create(user=profile, course=course)

    if not created:
        messages.info(request, "این دوره قبلاً به سبد خرید اضافه شده است.")

    return redirect('panel_user')


def index(request):
    list_course = models.Course.objects.all()
    list_future = models.FutureCourse.objects.all()
    list_teacher = models.Teacher.objects.all()
    list_blog = models.Blog.objects.all()
    list_category = models.Category.objects.all()

    user = request.user

    return render(request, 'index.html', {
        "Course": list_course,
        "FutureCourse": list_future,
        "Teacher": list_teacher,
        "Blog": list_blog,
        "Category": list_category,
        "user": user,
    })


def article(request):
    return render(request, 'article.html')


def blog(request):
    list_blog = models.Blog.objects.all()

    return render(request, 'blog.html', {
        "Blog": list_blog,
    })


def contact(request):
    return render(request, 'contact-us.html')


def course(request):
    list_course = models.Course.objects.all()
    list_future = models.FutureCourse.objects.all()

    return render(request, 'course.html', {
        "Course": list_course,
        "FutureCourse": list_future,
    })


def error(request):
    return render(request, 'error404.html')


def forget(request):
    return render(request, 'forget-password.html')


def teach(request):
    if request.method == "POST":
        name = request.POST.get("teacher_name")
        phone = request.POST.get("teacher_phone")
        email = request.POST.get("teacher_email")
        desc = request.POST.get("teacher_desc")

        teacher = models.Teacher(
            user=request.user,
            name=name,
            desc=desc,
        )
        teacher.save()

        models.TeacherInfo.objects.create(
            teacher=teacher,
            address="",
            phone=phone,
            email=email
        )

        request.user.is_teacher = True
        request.user.save()

        return HttpResponse("Teacher registered.")
    else:
        return render(request, "teach.html")


# ========== DETAIL VIEWS ==========

def coursedetail(request, code_course):
    data = models.Course.objects.filter(slug=code_course).first()
    all_courses = models.Course.objects.all()
    data.views += 1
    data.save()

    return render(request, "course.html", {
        "data": data,
        "Course": all_courses
    })


def futurecoursedetail(request, code_futurecourse):
    data = models.FutureCourse.objects.filter(slug=code_futurecourse).first()
    return render(request, "course.html", {"data": data})


def articledetail(request, code_article):
    data = models.Blog.objects.filter(slug=code_article).first()
    return render(request, "article.html", {"data": data})


def headercoursedetail(request, code_headercourse):
    data = models.HeaderCourse.objects.filter(slug=code_headercourse).first()
    return render(request, "course.html", {"data": data})


def categorydetail(request, code_category):
    category = get_object_or_404(models.Category, slug=code_category)

    courses = models.Course.objects.filter(category=category)

    # ---- GET FILTER PARAMETERS ----
    is_free = request.GET.get("free")
    is_paid = request.GET.get("cash")
    members = request.GET.get("vip")

    sort_option = request.GET.get("sort")

    tag = request.GET.get("tag")

    # ---- FILTER BY COURSE TYPE ----
    if is_free:
        courses = courses.filter(price=0)

    if is_paid:
        courses = courses.filter(price__gt=0)

    if members:
        courses = courses.filter(for_members=True)  # adjust based on your model

    # ---- FILTER BY TAG OR CHAPTER ----
    if tag:
        courses = courses.filter(tags__icontains=tag)

    # ---- SORTING ----
    if sort_option == "new":
        courses = courses.order_by("-created_at")
    elif sort_option == "old":
        courses = courses.order_by("created_at")
    elif sort_option == "ongoing":
        courses = courses.filter(status="ongoing")
    elif sort_option == "done":
        courses = courses.filter(status="finished")

    return render(request, "category.html", {
        "category": category,
        "Course": courses,
    })


def search_view(request):
    query = request.GET.get("q", "")
    results = []

    if query:
        results = Course.objects.filter(title__icontains=query)

    context = {
        "query": query,
        "results": results,
        "count": len(results)
    }
    return render(request, "search.html", context)


def autocomplete_search(request):
    query = request.GET.get("q", "")

    results = []
    if query:
        courses = Course.objects.filter(title__icontains=query)[:7]
        for c in courses:
            results.append({
                "title": c.title,
                "slug": c.slug,
                "image": c.image.url if c.image else "/static/images/default-course.png"
            })

    return JsonResponse({"results": results})


# def get_client_ip(request):
#     x_forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
#     if x_forwarded_for:
#         ip = x_forwarded_for.split(",")[0]  # first IP in the list
#     else:
#         ip = request.META.get("REMOTE_ADDR")
#     return ip
