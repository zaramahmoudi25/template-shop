from django.db import models
from slugify import slugify
# from django.utils import timezone
# from jalali_date import datetime2jalali
from django.conf import settings
from account_module.models import UserProfile, User
from .utils import persian_slugify


# --- USER & ROLES ---
class Role(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class Status(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


# --- TEACHER & RELATED ---
class Field(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Teacher(models.Model):
    name = models.CharField(max_length=100)
    desc = models.TextField(blank=True, null=True)
    field = models.ForeignKey(Field, on_delete=models.SET_NULL, null=True, blank=True)

    # signup_date = models.DateTimeField(auto_now_add=True)
    # ip_address = models.GenericIPAddressField(null=True, blank=True)

    # def jalali_signup_date(self):
    #     return datetime2jalali(self.signup_date).strftime('%Y/%m/%d _ %H:%M')
    # jalali_signup_date.short_description = "تاریخ ثبت‌نام (جلالی)"

    def __str__(self):
        return self.name


class University(models.Model):
    name = models.CharField(max_length=100)
    website = models.URLField(blank=True, null=True)
    address = models.CharField(max_length=255)

    def __str__(self):
        return self.name


class Education(models.Model):
    degree = models.CharField(max_length=100)
    field = models.CharField(max_length=100)
    start_year = models.IntegerField()
    end_year = models.IntegerField(blank=True, null=True)

    def __str__(self):
        return f"{self.degree} in {self.field}"


class TeacherInfo(models.Model):
    teacher = models.OneToOneField(Teacher, on_delete=models.CASCADE, related_name="info")
    education = models.ForeignKey(Education, on_delete=models.SET_NULL, null=True, blank=True)
    university = models.ForeignKey(University, on_delete=models.SET_NULL, null=True, blank=True)
    address = models.CharField(max_length=255)
    phone = models.CharField(max_length=20, blank=True, null=True)
    image = models.ImageField(upload_to="image/teacher_info", null=True, blank=True)
    email = models.EmailField()
    user = models.OneToOneField(settings.AUTH_USER_MODEL,
                                on_delete=models.CASCADE,
                                null=True, blank=True)

    def __str__(self):
        return f"Info for {self.teacher}"


# --- COURSE & RELATED ---
class Category(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    slug = models.SlugField(blank=True, allow_unicode=True)

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)


class Color(models.Model):
    level_name = models.CharField(max_length=50)
    color_code = models.CharField(max_length=7)

    def __str__(self):
        return f"{self.level_name} ({self.color_code})"


class Level(models.Model):
    name = models.CharField(max_length=100)
    color = models.OneToOneField(Color, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.name


class Syllabus(models.Model):
    title = models.CharField(max_length=100)
    time = models.CharField(max_length=50)
    description = models.TextField()
    video = models.URLField(blank=True, null=True)

    def __str__(self):
        return self.title


class Tags(models.Model):
    title = models.CharField(max_length=50)
    keyword = models.CharField(max_length=100)
    link = models.URLField(blank=True, null=True)

    def __str__(self):
        return self.title


class Course(models.Model):  # replaces Product
    title = models.CharField(max_length=100)
    description = models.TextField()
    price = models.DecimalField(max_digits=8, decimal_places=2)
    discount = models.IntegerField(default=0)
    image = models.ImageField(upload_to="image/course", blank=True, null=True)
    views = models.IntegerField(default=0)

    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE, related_name="courses")
    level = models.ForeignKey(Level, on_delete=models.SET_NULL, null=True)
    syllabus = models.ManyToManyField(Syllabus, blank=True)
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True)
    tags = models.ManyToManyField(Tags, blank=True)

    hours = models.CharField(default=0, max_length=100)
    slug = models.SlugField(blank=True, allow_unicode=True)

    intro_video = models.FileField(upload_to='course_videos/', null=True, blank=True)

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = persian_slugify(self.title)
        super().save(*args, **kwargs)


class CartItem(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, related_name='cart_items')
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    added_at = models.DateTimeField(auto_now_add=True)

    @property
    def total_price(self):
        return self.quantity * self.course.price

    def __str__(self):
        return f"{self.user.user.username} - {self.course.title}"


# --- ENROLLMENT ---
class Enrollment(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    enrollment_date = models.DateField(auto_now_add=True)
    status = models.ForeignKey(Status, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return f"{self.user} → {self.course}"


# --- BLOG & HEADERCOURSE (unchanged from your project) ---
class Blog(models.Model):
    title = models.CharField(max_length=100)
    image = models.ImageField(upload_to="image/blog", blank=True, null=True)
    desc = models.TextField()
    slug = models.SlugField(blank=True, null=True, allow_unicode=True)

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)
        super().save(*args, **kwargs)


class HeaderCourse(models.Model):
    title = models.CharField(max_length=100)
    slug = models.SlugField(blank=True, allow_unicode=True)

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)
        super().save(*args, **kwargs)


class FutureCourse(models.Model):
    title = models.CharField(max_length=100)
    desc = models.TextField()
    date = models.DateField(null=True, blank=True)
    slug = models.SlugField(blank=True, allow_unicode=True)

    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)
        super().save(*args, **kwargs)
